```python
import pandas as pd

df = pd.read_csv(r'C:\Users\hp\Downloads\WA_Fn-UseC_-Telco-Customer-Churn.csv')
print(df.head())

```

       customerID  gender  SeniorCitizen Partner Dependents  tenure PhoneService  \
    0  7590-VHVEG  Female              0     Yes         No       1           No   
    1  5575-GNVDE    Male              0      No         No      34          Yes   
    2  3668-QPYBK    Male              0      No         No       2          Yes   
    3  7795-CFOCW    Male              0      No         No      45           No   
    4  9237-HQITU  Female              0      No         No       2          Yes   
    
          MultipleLines InternetService OnlineSecurity  ... DeviceProtection  \
    0  No phone service             DSL             No  ...               No   
    1                No             DSL            Yes  ...              Yes   
    2                No             DSL            Yes  ...               No   
    3  No phone service             DSL            Yes  ...              Yes   
    4                No     Fiber optic             No  ...               No   
    
      TechSupport StreamingTV StreamingMovies        Contract PaperlessBilling  \
    0          No          No              No  Month-to-month              Yes   
    1          No          No              No        One year               No   
    2          No          No              No  Month-to-month              Yes   
    3         Yes          No              No        One year               No   
    4          No          No              No  Month-to-month              Yes   
    
                   PaymentMethod MonthlyCharges  TotalCharges Churn  
    0           Electronic check          29.85         29.85    No  
    1               Mailed check          56.95        1889.5    No  
    2               Mailed check          53.85        108.15   Yes  
    3  Bank transfer (automatic)          42.30       1840.75    No  
    4           Electronic check          70.70        151.65   Yes  
    
    [5 rows x 21 columns]
    


```python
# Basic info
print("Shape:", df.shape)
print("\nColumns:\n", df.columns.tolist())
print("\nData Types:\n")
print(df.dtypes)

# Summary stats
print("\nSummary:\n")
print(df.describe())

# Missing values
print("\nMissing Values:\n")
print(df.isnull().sum())

```

    Shape: (7043, 21)
    
    Columns:
     ['customerID', 'gender', 'SeniorCitizen', 'Partner', 'Dependents', 'tenure', 'PhoneService', 'MultipleLines', 'InternetService', 'OnlineSecurity', 'OnlineBackup', 'DeviceProtection', 'TechSupport', 'StreamingTV', 'StreamingMovies', 'Contract', 'PaperlessBilling', 'PaymentMethod', 'MonthlyCharges', 'TotalCharges', 'Churn']
    
    Data Types:
    
    customerID           object
    gender               object
    SeniorCitizen         int64
    Partner              object
    Dependents           object
    tenure                int64
    PhoneService         object
    MultipleLines        object
    InternetService      object
    OnlineSecurity       object
    OnlineBackup         object
    DeviceProtection     object
    TechSupport          object
    StreamingTV          object
    StreamingMovies      object
    Contract             object
    PaperlessBilling     object
    PaymentMethod        object
    MonthlyCharges      float64
    TotalCharges         object
    Churn                object
    dtype: object
    
    Summary:
    
           SeniorCitizen       tenure  MonthlyCharges
    count    7043.000000  7043.000000     7043.000000
    mean        0.162147    32.371149       64.761692
    std         0.368612    24.559481       30.090047
    min         0.000000     0.000000       18.250000
    25%         0.000000     9.000000       35.500000
    50%         0.000000    29.000000       70.350000
    75%         0.000000    55.000000       89.850000
    max         1.000000    72.000000      118.750000
    
    Missing Values:
    
    customerID          0
    gender              0
    SeniorCitizen       0
    Partner             0
    Dependents          0
    tenure              0
    PhoneService        0
    MultipleLines       0
    InternetService     0
    OnlineSecurity      0
    OnlineBackup        0
    DeviceProtection    0
    TechSupport         0
    StreamingTV         0
    StreamingMovies     0
    Contract            0
    PaperlessBilling    0
    PaymentMethod       0
    MonthlyCharges      0
    TotalCharges        0
    Churn               0
    dtype: int64
    


```python
# Convert TotalCharges to numeric if it's object
df['TotalCharges'] = pd.to_numeric(df['TotalCharges'], errors='coerce')

# Check again for missing values (after conversion)
print(df.isnull().sum())

```

    customerID           0
    gender               0
    SeniorCitizen        0
    Partner              0
    Dependents           0
    tenure               0
    PhoneService         0
    MultipleLines        0
    InternetService      0
    OnlineSecurity       0
    OnlineBackup         0
    DeviceProtection     0
    TechSupport          0
    StreamingTV          0
    StreamingMovies      0
    Contract             0
    PaperlessBilling     0
    PaymentMethod        0
    MonthlyCharges       0
    TotalCharges        11
    Churn                0
    dtype: int64
    


```python
df = df.dropna()
print("New shape after dropping nulls:", df.shape)

```

    New shape after dropping nulls: (7032, 21)
    


```python
import seaborn as sns
import matplotlib.pyplot as plt

# Churn countplot
sns.countplot(data=df, x='Churn')
plt.title('Churn Distribution')
plt.show()

```


    
![png](output_4_0.png)
    



```python
sns.countplot(data=df, x='gender', hue='Churn')
plt.title('Churn Rate by Gender')
plt.show()

```


    
![png](output_5_0.png)
    



```python
sns.countplot(data=df, x='Contract', hue='Churn')
plt.title('Churn Rate by Contract Type')
plt.xticks(rotation=15)
plt.show()

```


    
![png](output_6_0.png)
    



```python
sns.boxplot(data=df, x='Churn', y='MonthlyCharges')
plt.title('Monthly Charges vs Churn')
plt.show()

```


    
![png](output_7_0.png)
    



```python
sns.histplot(data=df, x='tenure', hue='Churn', kde=True, bins=30)
plt.title('Tenure Distribution by Churn')
plt.show()

```


    
![png](output_8_0.png)
    



```python
# Drop customerID (not useful)
df = df.drop('customerID', axis=1)

# Convert 'Churn' column to binary
df['Churn'] = df['Churn'].map({'Yes': 1, 'No': 0})

# Convert categorical columns using get_dummies
df_encoded = pd.get_dummies(df, drop_first=True)

print("Shape after encoding:", df_encoded.shape)

```

    Shape after encoding: (7032, 31)
    


```python
from sklearn.model_selection import train_test_split

X = df_encoded.drop('Churn', axis=1)
y = df_encoded['Churn']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

print("Training samples:", X_train.shape[0])
print("Test samples:", X_test.shape[0])

```

    Training samples: 5625
    Test samples: 1407
    


```python
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix

# Train model
model = LogisticRegression(max_iter=1000)
model.fit(X_train, y_train)

# Predictions
y_pred = model.predict(X_test)

# Evaluation
print(confusion_matrix(y_test, y_pred))
print(classification_report(y_test, y_pred))

```

    [[915 118]
     [181 193]]
                  precision    recall  f1-score   support
    
               0       0.83      0.89      0.86      1033
               1       0.62      0.52      0.56       374
    
        accuracy                           0.79      1407
       macro avg       0.73      0.70      0.71      1407
    weighted avg       0.78      0.79      0.78      1407
    
    

    C:\Users\hp\anaconda3\Lib\site-packages\sklearn\linear_model\_logistic.py:469: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    


```python

```
